﻿using ecommerce.Core.Models;

namespace ecommerce.Core.Services.Interfaces
{
    public interface ICustomerService : IService<Customer>
    {
        
    }
}