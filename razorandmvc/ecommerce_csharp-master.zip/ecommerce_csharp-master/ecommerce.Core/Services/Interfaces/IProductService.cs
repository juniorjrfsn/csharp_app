﻿using ecommerce.Core.Models;

namespace ecommerce.Core.Services.Interfaces
{
    public interface IProductService : IService<Product>
    {
        
    }
}