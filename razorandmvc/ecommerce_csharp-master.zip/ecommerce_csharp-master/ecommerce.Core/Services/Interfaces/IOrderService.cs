﻿using ecommerce.Core.Models;

namespace ecommerce.Core.Services.Interfaces
{
    public interface IOrderService : IService<Order>
    {
        
    }
}