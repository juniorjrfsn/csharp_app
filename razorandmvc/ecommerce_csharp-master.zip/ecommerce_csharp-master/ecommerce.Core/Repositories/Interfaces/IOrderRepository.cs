﻿using ecommerce.Core.Models;

namespace ecommerce.Core.Repositories.Interfaces
{
    public interface IOrderRepository : IRepository<Order>
    {
        
    }
}