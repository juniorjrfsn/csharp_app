﻿using ecommerce.Core.Models;

namespace ecommerce.Core.Repositories.Interfaces
{
    public interface ICustomerRepository : IRepository<Customer>
    {
        
    }
}