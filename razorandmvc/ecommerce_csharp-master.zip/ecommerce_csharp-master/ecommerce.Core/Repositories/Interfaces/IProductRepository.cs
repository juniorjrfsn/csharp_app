﻿using ecommerce.Core.Models;

namespace ecommerce.Core.Repositories.Interfaces
{
    public interface IProductRepository : IRepository<Product>
    {
        
    }
}