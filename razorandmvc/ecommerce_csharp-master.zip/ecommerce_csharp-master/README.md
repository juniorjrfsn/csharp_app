# ecommerce_csharp

this is mockup of an ecommerce shop api, made with .NET 5 C#. dapper, entity framework core, and ASP.NET core.
