# RespositoryServicePatternDemo

This example project is used in the following blog posts:

* [The Repository-Service Pattern with DI and ASP.NET Core](https://exceptionnotfound.net/the-repository-service-pattern-with-dependency-injection-and-asp-net-core/)
